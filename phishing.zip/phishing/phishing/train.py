import numpy as np
import pandas as pd
import re
import matplotlib.pyplot as plt

from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, plot_tree

# Function to tokenize URLs
def tokenize_url(url):
    return url.replace('/', '.').split('.')

# Function to clean text
def clean_text(text):
    return text.replace('.', ' ').replace('/', ' ')

# Function to count the number of digits in text
def count_digits(text):
    return len(re.findall('\d', text))

# Function to count the number of dots in text
def count_dots(text):
    return len(re.findall('\.', text))

# Function to count the number of bars in text
def count_bars(text):
    return len(re.findall('/', text))

# Function to extract top terms from DataFrame
def top_terms(df, n):
    terms = {}
    for url, _ in df.values:
        for word in tokenize_url(url):
            if word != '':
                terms[word] = terms.get(word, 0) + 1
    return [t[0] for t in sorted(terms.items(), key=lambda x: x[1], reverse=True)[:n]]

# Read the dataset
df = pd.read_csv(r'C:\Users\91805\OneDrive\Desktop\phishingnew2\phishing\phishing\new_data_urls.csv')

# Balance the dataset
df_maj = df[df['status'] == 1]
df_min = df[df['status'] == 0]
df_maj_sampled = df_maj.sample(len(df_min), random_state=42)
df_balanced = pd.concat([df_maj_sampled, df_min])
df_balanced.reset_index(inplace=True, drop=True)

# Define vocabulary and corpus
VOCABULARY = top_terms(df_balanced, n=10)
CORPUS = [clean_text(url) for url in df_balanced.url]

# Vectorize URLs
vectorizer = CountVectorizer(binary=True, vocabulary=VOCABULARY)
doc_term_matrix = vectorizer.fit_transform(CORPUS)

# Create DataFrame from document-term matrix
matrix = pd.DataFrame(doc_term_matrix.A, columns=VOCABULARY)
matrix['dots'] = [count_dots(text) for text in df_balanced.url]
matrix['bars'] = [count_bars(text) for text in df_balanced.url]
matrix['length'] = [len(text) for text in CORPUS]
matrix['digits'] = [count_digits(text) for text in CORPUS]

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(matrix.values, df_balanced['status'].values, test_size=0.2, random_state=42)

# Train Decision Tree Classifier
clf = DecisionTreeClassifier()
clf.fit(X_train, y_train)

import pickle

# Save the trained model to a file
with open('decision_tree_model.pkl', 'wb') as f:
    pickle.dump(clf, f)

# Save the vectorizer to a file
with open('count_vectorizer.pkl', 'wb') as f:
    pickle.dump(vectorizer, f)
# Predict and evaluate
y_pred = clf.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
confusion = confusion_matrix(y_test, y_pred)


# Print results
print("Accuracy:", accuracy)
print("Confusion Matrix:\n", confusion)


# Example user input URL


# Function to preprocess user input URL
def preprocess_input_url(url):
    cleaned_url = clean_text(url)
    tokenized_url = tokenize_url(cleaned_url)
    url_vector = vectorizer.transform([' '.join(tokenized_url)]).toarray()  # Join tokens into a single string
    num_dots = count_dots(url)
    num_bars = count_bars(url)
    url_length = len(cleaned_url)
    num_digits_url = count_digits(cleaned_url)
    return np.concatenate((url_vector, [[num_dots, num_bars, url_length, num_digits_url]]), axis=1)

# Example user input URL
user_input_url = "google.com"

# Preprocess user input URL
user_input_features = preprocess_input_url(user_input_url)

# Predict with the trained model
prediction = clf.predict(user_input_features)

# Display prediction
if prediction[0] == 1:
    print("The URL '{}' is classified as clean.".format(user_input_url))
else:
    print("The URL '{}' is classified as phishing.".format(user_input_url))
