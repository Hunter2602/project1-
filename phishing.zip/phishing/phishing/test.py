import numpy as np
import pandas as pd
import re
import pickle

# Function to tokenize URLs
def tokenize_url(url):
    return url.replace('/', '.').split('.')

# Function to clean text
def clean_text(text):
    return text.replace('.', ' ').replace('/', ' ')

# Function to count the number of digits in text
def count_digits(text):
    return len(re.findall('\d', text))

# Function to count the number of dots in text
def count_dots(text):
    return len(re.findall('\.', text))

# Function to count the number of bars in text
def count_bars(text):
    return len(re.findall('/', text))

# Example user input URL
user_input_url = "www.teleplaza.com/Events/web.html"
# Function to preprocess user input URL
def preprocess_input_url(url):
    cleaned_url = clean_text(url)
    tokenized_url = tokenize_url(cleaned_url)
    url_vector = vectorizer.transform([' '.join(tokenized_url)]).toarray()  # Join tokens into a single string
    num_dots = count_dots(url)
    num_bars = count_bars(url)
    url_length = len(cleaned_url)
    num_digits_url = count_digits(cleaned_url)
    return np.concatenate((url_vector, [[num_dots, num_bars, url_length, num_digits_url]]), axis=1)

# Load the decision tree model from file
with open('decision_tree_model.pkl', 'rb') as f:
    clf = pickle.load(f)

# Load the vectorizer from file
with open('count_vectorizer.pkl', 'rb') as f:
    vectorizer = pickle.load(f)

# Preprocess user input URL
user_input_features = preprocess_input_url(user_input_url)

# Predict with the loaded model
prediction = clf.predict(user_input_features)

# Display prediction
if prediction[0] == 1:
    print("The URL '{}' is classified as clean.".format(user_input_url))
else:
    print("The URL '{}' is classified as phishing.".format(user_input_url))
