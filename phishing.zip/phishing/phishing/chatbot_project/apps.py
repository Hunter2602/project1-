from django.apps import AppConfig


class ChatbotProjectConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'chatbot_project'
