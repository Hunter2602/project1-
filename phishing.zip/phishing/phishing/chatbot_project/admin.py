from django.contrib import admin

from chatbot_project.models import Response

# Register your models here.
admin.site.register(Response)
# admin.site.register(Topic)
